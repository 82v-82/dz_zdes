"""Собственная кнопка приложения."""
import tkinter as tk


class AppButton(tk.Button):
    def __init__(self, master, text, command=None, color="#2b5fb4", **kwargs):
        super().__init__(
            master,
            text=text,
            command=command,
            bg=color,
            fg="white",
            activebackground="#1d4486",
            activeforeground="white",
            relief="flat",
            padx=12,
            pady=4,
            cursor="hand2",
            **kwargs,
        )
