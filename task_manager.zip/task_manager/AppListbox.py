"""Собственный список для отображения задач."""
import tkinter as tk


class AppListbox(tk.Listbox):
    def __init__(self, master, **kwargs):
        super().__init__(master, font=("Arial", 12), activestyle="none",
                         selectbackground="#2b5fb4", height=12, **kwargs)

    def show_tasks(self, tasks):
        """Метод показа задач: полностью перерисовывает список."""
        self.delete(0, tk.END)
        for task in tasks:
            mark = "[x]" if task["done"] else "[ ]"
            self.insert(tk.END, f"{mark} {task['title']}")
            if task["done"]:
                self.itemconfig(tk.END, fg="gray")

    def selected_index(self):
        selection = self.curselection()
        return selection[0] if selection else None
