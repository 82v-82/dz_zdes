"""Слой логики (view/controller): связывает Storage и Interface.

Запуск: python view.py
"""
import tkinter as tk

from Interface import Interface
from storage import Storage


class TaskView:
    def __init__(self, root):
        self.storage = Storage()
        self.tasks = self.storage.load()
        self.ui = Interface(root)
        self.ui.set_handlers(self.add_task, self.toggle_task, self.delete_task)
        self.refresh()

    def refresh(self):
        self.ui.show_tasks(self.tasks)

    def _save_and_refresh(self):
        self.storage.save(self.tasks)
        self.refresh()

    def add_task(self):
        title = self.ui.get_input()
        if not title:
            self.ui.warn("Введите название задачи.")
            return
        self.tasks.append({"title": title, "done": False})
        self.ui.clear_input()
        self._save_and_refresh()

    def toggle_task(self):
        index = self.ui.selected_index()
        if index is None:
            self.ui.warn("Выберите задачу.")
            return
        self.tasks[index]["done"] = not self.tasks[index]["done"]
        self._save_and_refresh()

    def delete_task(self):
        index = self.ui.selected_index()
        if index is None:
            self.ui.warn("Выберите задачу.")
            return
        del self.tasks[index]
        self._save_and_refresh()


if __name__ == "__main__":
    root = tk.Tk()
    TaskView(root)
    root.mainloop()
