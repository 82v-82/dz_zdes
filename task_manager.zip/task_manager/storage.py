"""Слой хранения: сохранение и загрузка задач в JSON."""
import json
import os


class Storage:
    def __init__(self, path="tasks.json", legacy_txt="tasks.txt"):
        self.path = path
        self.legacy_txt = legacy_txt

    def load(self):
        """Возвращает список задач: [{"title": str, "done": bool}, ...]."""
        if os.path.exists(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                return data if isinstance(data, list) else []
            except (json.JSONDecodeError, OSError):
                return []
        return self._migrate_from_txt()

    def save(self, tasks):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(tasks, f, ensure_ascii=False, indent=4)

    def _migrate_from_txt(self):
        """Одноразовый перенос старых задач из txt в новый формат."""
        if not os.path.exists(self.legacy_txt):
            return []
        with open(self.legacy_txt, "r", encoding="utf-8") as f:
            tasks = [{"title": line.strip(), "done": False}
                     for line in f if line.strip()]
        self.save(tasks)
        return tasks
