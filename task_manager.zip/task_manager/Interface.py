"""Слой интерфейса: собирает окно из виджетов. Логики данных здесь нет."""
import tkinter as tk
from tkinter import messagebox

from AppButton import AppButton
from AppLabel import AppLabel
from AppListbox import AppListbox


class Interface:
    def __init__(self, root):
        self.root = root
        root.title("Task Manager")
        root.geometry("460x480")

        top = tk.Frame(root)
        top.pack(fill="x", padx=10, pady=10)
        self.entry = tk.Entry(top, font=("Arial", 12))
        self.entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.add_btn = AppButton(top, "Добавить")
        self.add_btn.pack(side="right")

        mid = tk.Frame(root)
        mid.pack(fill="both", expand=True, padx=10)
        self.listbox = AppListbox(mid)
        scroll = tk.Scrollbar(mid, command=self.listbox.yview)
        self.listbox.config(yscrollcommand=scroll.set)
        self.listbox.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        bottom = tk.Frame(root)
        bottom.pack(fill="x", padx=10, pady=10)
        self.toggle_btn = AppButton(bottom, "Выполнено / Нет")
        self.toggle_btn.pack(side="left")
        self.delete_btn = AppButton(bottom, "Удалить", color="#b42b2b")
        self.delete_btn.pack(side="left", padx=8)

        self.label = AppLabel(root)
        self.label.pack(fill="x", padx=10, pady=(0, 10))

    def set_handlers(self, on_add, on_toggle, on_delete):
        self.add_btn.config(command=on_add)
        self.toggle_btn.config(command=on_toggle)
        self.delete_btn.config(command=on_delete)
        self.entry.bind("<Return>", lambda e: on_add())

    def get_input(self):
        return self.entry.get().strip()

    def clear_input(self):
        self.entry.delete(0, tk.END)

    def selected_index(self):
        return self.listbox.selected_index()

    def show_tasks(self, tasks):
        """Показывает задачи в списке и обновляет статистику."""
        self.listbox.show_tasks(tasks)
        self.label.show_stats(tasks)

    def warn(self, text):
        messagebox.showwarning("Task Manager", text)
