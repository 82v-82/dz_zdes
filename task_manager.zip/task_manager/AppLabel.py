"""Собственная метка приложения: показывает статистику задач."""
import tkinter as tk


class AppLabel(tk.Label):
    def __init__(self, master, text="", **kwargs):
        super().__init__(master, text=text, anchor="w",
                         font=("Arial", 10), **kwargs)

    def show_stats(self, tasks):
        """Метод показа информации о задачах."""
        total = len(tasks)
        done = sum(1 for t in tasks if t["done"])
        self.config(text=f"Всего: {total} | Выполнено: {done} | "
                         f"Осталось: {total - done}")
