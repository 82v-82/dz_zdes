import tkinter as tk


class AppButton(tk.Button):
    def __init__(self, master, **kwargs):
        kwargs.setdefault("bg", "#26344b")
        kwargs.setdefault("fg", "white")
        kwargs.setdefault("activebackground", "#354968")
        kwargs.setdefault("activeforeground", "white")
        kwargs.setdefault("relief", "flat")
        kwargs.setdefault("font", ("Arial", 10, "bold"))
        kwargs.setdefault("cursor", "hand2")
        kwargs.setdefault("padx", 12)
        kwargs.setdefault("pady", 7)
        super().__init__(master, **kwargs)


class AppEntry(tk.Entry):
    def __init__(self, master, **kwargs):
        kwargs.setdefault("bg", "#1b2638")
        kwargs.setdefault("fg", "white")
        kwargs.setdefault("insertbackground", "white")
        kwargs.setdefault("relief", "flat")
        kwargs.setdefault("font", ("Arial", 11))
        kwargs.setdefault("highlightthickness", 1)
        kwargs.setdefault("highlightbackground", "#35445c")
        kwargs.setdefault("highlightcolor", "#20d9e8")
        super().__init__(master, **kwargs)


class AppLabel(tk.Label):
    def __init__(self, master, **kwargs):
        kwargs.setdefault("bg", "#111827")
        kwargs.setdefault("fg", "#e8eefc")
        kwargs.setdefault("font", ("Arial", 10))
        super().__init__(master, **kwargs)


class AppListbox(tk.Listbox):
    def __init__(self, master, **kwargs):
        kwargs.setdefault("bg", "#1b2638")
        kwargs.setdefault("fg", "#e8eefc")
        kwargs.setdefault("selectbackground", "#354f7a")
        kwargs.setdefault("selectforeground", "white")
        kwargs.setdefault("font", ("Arial", 10))
        kwargs.setdefault("relief", "flat")
        kwargs.setdefault("activestyle", "none")
        super().__init__(master, **kwargs)
