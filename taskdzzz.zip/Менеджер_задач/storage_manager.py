import json
import os
from task import Task


class StorageManager:
    """Загрузка и сохранение задач в JSON."""

    def __init__(self, filename="data/tasks.json"):
        self.filename = filename
        folder = os.path.dirname(filename)
        if folder:
            os.makedirs(folder, exist_ok=True)

    def load(self):
        if not os.path.exists(self.filename):
            return []
        try:
            with open(self.filename, "r", encoding="utf-8") as file:
                data = json.load(file)
            return [Task.from_dict(item) for item in data]
        except (json.JSONDecodeError, KeyError, TypeError):
            return []

    def save(self, tasks):
        with open(self.filename, "w", encoding="utf-8") as file:
            json.dump([task.to_dict() for task in tasks],
                      file, ensure_ascii=False, indent=4)

    def add(self, task):
        tasks = self.load()
        tasks.append(task)
        self.save(tasks)

    def update(self, updated_task):
        tasks = self.load()
        for index, task in enumerate(tasks):
            if task.id == updated_task.id:
                tasks[index] = updated_task
                break
        self.save(tasks)

    def delete(self, task_id):
        tasks = [task for task in self.load() if task.id != task_id]
        self.save(tasks)
