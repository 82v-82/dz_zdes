import tkinter as tk
from tkinter import messagebox
from app_widgets import AppButton, AppEntry, AppLabel, AppListbox


class Interface:
    """Отвечает только за отображение окна и ввод пользователя."""

    def __init__(self, root):
        self.root = root
        self.root.title("Менеджер задач v0.2.0")
        self.root.geometry("850x570")
        self.root.minsize(700, 480)
        self.root.configure(bg="#111827")

        self.title_entry = None
        self.description_entry = None
        self.author_entry = None
        self.task_list = None
        self.status_label = None

        self.build()

    def build(self):
        header = tk.Frame(self.root, bg="#111827")
        header.pack(fill="x", padx=22, pady=(18, 10))

        AppLabel(header, text="Менеджер задач", font=("Arial", 20, "bold"),
                 fg="#ffffff").pack(side="left")
        AppLabel(header, text="v0.2.0", fg="#20d9e8").pack(side="left", padx=10)

        content = tk.Frame(self.root, bg="#111827")
        content.pack(fill="both", expand=True, padx=22, pady=10)

        left = tk.Frame(content, bg="#172235", padx=15, pady=15)
        left.pack(side="left", fill="y", padx=(0, 12))

        AppLabel(left, text="НОВАЯ / ИЗМЕНЕНИЕ ЗАДАЧИ",
                 bg="#172235", font=("Arial", 10, "bold")).pack(anchor="w", pady=(0, 12))

        AppLabel(left, text="Название", bg="#172235").pack(anchor="w")
        self.title_entry = AppEntry(left, width=28)
        self.title_entry.pack(fill="x", pady=(4, 12))

        AppLabel(left, text="Описание", bg="#172235").pack(anchor="w")
        self.description_entry = AppEntry(left, width=28)
        self.description_entry.pack(fill="x", pady=(4, 12))

        AppLabel(left, text="Автор", bg="#172235").pack(anchor="w")
        self.author_entry = AppEntry(left, width=28)
        self.author_entry.pack(fill="x", pady=(4, 14))

        self.add_button = AppButton(left, text="+ Создать задачу")
        self.add_button.pack(fill="x", pady=4)
        self.edit_button = AppButton(left, text="Сохранить изменения")
        self.edit_button.pack(fill="x", pady=4)
        self.clear_button = AppButton(left, text="Очистить поля", bg="#35445c")
        self.clear_button.pack(fill="x", pady=4)

        right = tk.Frame(content, bg="#172235", padx=15, pady=15)
        right.pack(side="left", fill="both", expand=True)

        AppLabel(right, text="СПИСОК ЗАДАЧ", bg="#172235",
                 font=("Arial", 10, "bold")).pack(anchor="w", pady=(0, 10))

        list_frame = tk.Frame(right, bg="#172235")
        list_frame.pack(fill="both", expand=True)

        self.task_list = AppListbox(list_frame, height=16)
        self.task_list.pack(side="left", fill="both", expand=True)
        scrollbar = tk.Scrollbar(list_frame, command=self.task_list.yview)
        scrollbar.pack(side="right", fill="y")
        self.task_list.config(yscrollcommand=scrollbar.set)

        buttons = tk.Frame(right, bg="#172235")
        buttons.pack(fill="x", pady=(12, 0))
        self.done_button = AppButton(buttons, text="Изменить статус")
        self.done_button.pack(side="left", padx=(0, 5))
        self.delete_button = AppButton(buttons, text="Удалить", bg="#713b4b")
        self.delete_button.pack(side="left")

        self.status_label = AppLabel(self.root, text="Готово",
                                     fg="#20d9e8", anchor="w")
        self.status_label.pack(fill="x", padx=24, pady=(0, 12))

    def get_input(self):
        return {
            "title": self.title_entry.get().strip(),
            "description": self.description_entry.get().strip(),
            "author": self.author_entry.get().strip()
        }

    def set_input(self, task):
        self.clear_inputs()
        self.title_entry.insert(0, task.title)
        self.description_entry.insert(0, task.description)
        self.author_entry.insert(0, task.author)

    def clear_inputs(self):
        self.title_entry.delete(0, tk.END)
        self.description_entry.delete(0, tk.END)
        self.author_entry.delete(0, tk.END)

    def show_tasks(self, tasks):
        self.task_list.delete(0, tk.END)
        for task in tasks:
            mark = "✓" if task.status else "○"
            line = f"{mark}  #{task.id}  {task.title}  —  {task.author}"
            self.task_list.insert(tk.END, line)

    def get_selected_index(self):
        selected = self.task_list.curselection()
        return selected[0] if selected else None

    def ask_confirm(self, message):
        return messagebox.askyesno("Подтверждение", message)

    def show_error(self, message):
        messagebox.showerror("Ошибка", message)

    def set_status(self, message):
        self.status_label.config(text=message)
