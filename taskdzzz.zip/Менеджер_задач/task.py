from datetime import datetime


class Task:
    """Одна задача."""

    def __init__(self, task_id, title, description="", status=False,
                 author="", created_at=None):
        self.id = task_id
        self.title = title
        self.description = description
        self.status = status
        self.author = author
        self.created_at = created_at or datetime.now().strftime("%d.%m.%Y %H:%M")

    def to_dict(self):
        """Преобразует задачу в словарь для JSON."""
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "status": self.status,
            "author": self.author,
            "created_at": self.created_at
        }

    @classmethod
    def from_dict(cls, data):
        """Создаёт задачу из словаря."""
        return cls(
            data["id"],
            data["title"],
            data.get("description", ""),
            data.get("status", False),
            data.get("author", ""),
            data.get("created_at")
        )
