from tkinter import messagebox
from task import Task
from storage_manager import StorageManager
from interface import Interface


class TaskManager:
    """Связывает интерфейс, задачи и сохранение данных."""

    def __init__(self, root):
        self.storage = StorageManager()
        self.interface = Interface(root)
        self.tasks = self.storage.load()
        self.selected_task_id = None

        self.interface.add_button.config(command=self.create_task)
        self.interface.edit_button.config(command=self.edit_task)
        self.interface.delete_button.config(command=self.delete_task)
        self.interface.done_button.config(command=self.toggle_status)
        self.interface.clear_button.config(command=self.clear_form)
        self.interface.task_list.bind("<<ListboxSelect>>", self.select_task)

        self.show_tasks()

    def run(self):
        self.interface.root.mainloop()

    def show_tasks(self):
        self.interface.show_tasks(self.tasks)

    def create_task(self):
        data = self.interface.get_input()
        if not data["title"]:
            self.interface.show_error("Введите название задачи.")
            return

        new_id = max([task.id for task in self.tasks], default=0) + 1
        task = Task(new_id, data["title"], data["description"],
                    False, data["author"])
        self.tasks.append(task)
        self.storage.add(task)
        self.show_tasks()
        self.clear_form()
        self.interface.set_status("Задача создана.")

    def select_task(self, event=None):
        index = self.interface.get_selected_index()
        if index is None or index >= len(self.tasks):
            return
        task = self.tasks[index]
        self.selected_task_id = task.id
        self.interface.set_input(task)

    def edit_task(self):
        if self.selected_task_id is None:
            self.interface.show_error("Сначала выберите задачу в списке.")
            return

        data = self.interface.get_input()
        if not data["title"]:
            self.interface.show_error("Название не может быть пустым.")
            return

        for task in self.tasks:
            if task.id == self.selected_task_id:
                task.title = data["title"]
                task.description = data["description"]
                task.author = data["author"]
                self.storage.update(task)
                break

        self.show_tasks()
        self.clear_form()
        self.interface.set_status("Изменения сохранены.")

    def delete_task(self):
        if self.selected_task_id is None:
            self.interface.show_error("Выберите задачу для удаления.")
            return
        if not self.interface.ask_confirm("Удалить выбранную задачу?"):
            return

        task_id = self.selected_task_id
        self.tasks = [task for task in self.tasks if task.id != task_id]
        self.storage.delete(task_id)
        self.show_tasks()
        self.clear_form()
        self.interface.set_status("Задача удалена.")

    def toggle_status(self):
        if self.selected_task_id is None:
            self.interface.show_error("Сначала выберите задачу.")
            return

        for task in self.tasks:
            if task.id == self.selected_task_id:
                task.status = not task.status
                self.storage.update(task)
                break

        self.show_tasks()
        self.interface.set_status("Статус задачи изменён.")

    def clear_form(self):
        self.selected_task_id = None
        self.interface.clear_inputs()
        self.interface.task_list.selection_clear(0, "end")
